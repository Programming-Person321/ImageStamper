#!/bin/bash
./jre/bin/java -cp ImageStamper.jar Start
